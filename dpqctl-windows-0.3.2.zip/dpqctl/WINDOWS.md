# Windows で dpqctl を使う（利用者の端末）

検証では Windows の PC を「利用者本人のスマートフォン」の役にします。
利用者の鍵（秘密鍵）は Windows の中にだけ置き、サーバの機械には置きません。
お店の役は、これまでどおり Windows の PowerShell から dpq-api を curl で呼びます。

> 管理者の操作（名簿の初期化、`party add`、`api user add` など）は、これまでどおり hub のある機械（dpq-vm-a）で行います。Windows には管理トークンを置きません。

---

## 1. Python を入れる（最初に1回）

PowerShell で次のどちらかを実行します。

```powershell
winget install -e --id Python.Python.3.12
```

または https://www.python.org/ からインストーラを入れます（「Add python.exe to PATH」にチェック）。

入ったら、PowerShell を開き直して確認します。

```powershell
py --version
py -m pip install cryptography
```

## 2. dpqctl を置く

`dpqctl-windows-0.3.2.zip` を展開し、たとえば `C:\Users\<ユーザー名>\dpqctl` に置きます。中身は次のとおりです。

```
dpqctl\
  dpqctl.cmd     ← これを実行する
  dpqd\          ← 本体（Linux 版と同じ Python のコード）
  WINDOWS.md
```

## 3. 使う

```powershell
cd ~\dpqctl
$env:DPQ_HUB = "http://192.168.1.20:8700"     # hub の URL（家の LAN の IP に読み替える）
.\dpqctl.cmd status
```

全サーバが「在籍」と出れば、Windows から hub とサーバに届いています。

### 利用者として登録し、同意する

```powershell
.\dpqctl.cmd wallet create   --subject u1
.\dpqctl.cmd wallet register --subject u1 --name "山田 太郎" --birth 1995-04-12 --address "東京都千代田区千代田1-1"
.\dpqctl.cmd wallet consent  --subject u1 --vendor webshop --purpose age --age 18 --rounds 100 -o a1.json
```

`a1.json` ができたら、そのまま API で照会できます（お店の役。手順は API.md の 4.3）。

```powershell
curl.exe -s -X POST "$API/v1/query?type=age_over&age=18" -H "Authorization: Bearer $T" -H "Content-Type: application/json" --data-binary "@a1.json"
```

本人が照会の履歴を見るとき：

```powershell
.\dpqctl.cmd wallet audit --subject u1
```

## 4. 鍵の置き場所

| もの | 場所 |
|---|---|
| 利用者 u1 の秘密鍵 | `C:\Users\<ユーザー名>\.dpq\wallets\u1.key` |

- Windows のユーザーフォルダの中なので、ほかの Windows ユーザーからは読めません。ただし暗号化はしていません。
- このファイルが「スマホの中の鍵」にあたります。コピーされると本人になりすませるので、人に渡したり、資料に写したりしないでください。
- 消すと、同じ利用者ID（u1）では二度と同意できなくなります（試作では鍵の再発行に未対応）。

## 5. うまく動かないとき

| 症状 | 対処 |
|---|---|
| `py` が見つからない | Python を入れたあと PowerShell を開き直す。Microsoft Store 版の Python なら `dpqctl.cmd` が自動で `python` を使う |
| `No module named 'cryptography'` | `py -m pip install cryptography` |
| `status` で接続できない | `$env:DPQ_HUB` の IP、Windows と各機械が同じ LAN にいるか、Alma の firewalld（8701/tcp）を確認 |
| 「同意の発行時刻が未来」 | Windows の時計がずれている。「設定 → 時刻と言語 → 今すぐ同期」 |
