"""DPQ（分散型個人情報照会システム）ネットワーク版。"""
from .common import VERSION as __version__  # noqa: F401
