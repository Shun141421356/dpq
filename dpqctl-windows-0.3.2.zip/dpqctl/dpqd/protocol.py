"""照会プロトコルの定義：同意トークン、照会依頼書、サーバ選定、名簿の版、ビーコン検証。

すべてのメッセージは JSON（dict）で表し、署名は正規化 JSON に対する Ed25519。
"""
from __future__ import annotations

import hashlib
import secrets
import time

from .common import canon, sha256_hex, verify

# ---- ポリシー（全サーバ共通の定数） ----------------------------------------
PURPOSE = {
    "age_over": "age_verification",
    "name_match": "identity_verification",
    "delivery_token": "delivery",
}
ALLOWED_AGES = (18, 20, 65)
MAX_CONSENT_TTL = 600        # 同意の有効期限（秒）の上限
MAX_CONSENT_ROUNDS = 100     # 同意の有効期間（ビーコンの回数）の上限
ROUND_MARGIN = 20            # 掲示板の記録を捨てるまでの余裕（回数）
MAX_CLOCK_SKEW = 30          # 許容する時計のずれ（秒）
DIR_MIN_DELAY = 2            # 名簿の新しい版は「現在の回 + 2」以降から有効
BIRTH_BITS = 20


# ---- 同意トークン -----------------------------------------------------------
CONSENT_FIELDS = ("subject", "vendor", "purpose", "scope", "iat", "exp", "from", "until", "nonce")


def consent_body(c: dict) -> bytes:
    return canon({k: c[k] for k in CONSENT_FIELDS})


def consent_id(c: dict) -> str:
    return sha256_hex(consent_body(c) + c["sig"].encode())


def make_consent(key, subject, vendor, purpose, scope, current_round, rounds=60, ttl=300,
                 clock_skew=0.0) -> dict:
    now = time.time() + clock_skew
    c = {"subject": subject, "vendor": vendor, "purpose": purpose, "scope": scope,
         "iat": now, "exp": now + ttl, "from": current_round, "until": current_round + rounds,
         "nonce": secrets.token_hex(16)}
    c["sig"] = key.sign(consent_body(c))
    return c


# ---- 照会依頼書 -------------------------------------------------------------
REQUEST_CORE = ("vendor", "subject", "qtype", "params", "consent", "round", "dir_version",
                "dir_hash", "nonce")


def request_digest(r: dict) -> str:
    return sha256_hex(canon({k: r[k] for k in REQUEST_CORE}))


def board_post_message(digest: str, cid: str) -> bytes:
    return canon({"post": digest, "consent_id": cid})


# ---- ビーコン（ハッシュチェーン） -------------------------------------------

def H(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def chain_down(value: bytes, steps: int) -> bytes:
    for _ in range(steps):
        value = H(value)
    return value


class BeaconVerifier:
    """ビーコン値の検証。最後に確かめた (回, 値) を覚えておき、差分だけハッシュする。"""

    def __init__(self, anchor_hex: str):
        self.anchor = anchor_hex
        self.known = {0: bytes.fromhex(anchor_hex)}
        self.last = 0

    def verify(self, rnd: int, value_hex: str) -> bool:
        v = bytes.fromhex(value_hex)
        if rnd in self.known:
            return self.known[rnd] == v
        if rnd > self.last:
            ok = chain_down(v, rnd - self.last) == self.known[self.last]
        else:
            ok = chain_down(self.known[self.last], self.last - rnd) == v
        if ok and rnd > self.last:
            self.known = {0: self.known[0], rnd: v}
            self.last = rnd
        return ok


# ---- サーバ選定 -------------------------------------------------------------

def _h(*parts: bytes) -> bytes:
    h = hashlib.sha256()
    for p in parts:
        h.update(len(p).to_bytes(4, "big"))
        h.update(p)
    return h.digest()


def select_servers(members: list, beacon_value_hex: str, digest_hex: str, k: int,
                   distinct: str = "region") -> list:
    seed = _h(b"select", bytes.fromhex(beacon_value_hex), bytes.fromhex(digest_hex))
    order = sorted(members, key=lambda m: _h(seed, m["id"].encode()))
    chosen, used = [], set()
    for m in order:
        tag = m.get(distinct) if distinct in ("region", "operator") else m["id"]
        if tag in used:
            continue
        chosen.append(m["id"])
        used.add(tag)
        if len(chosen) == k:
            return chosen
    raise ValueError(f"条件（{distinct} の重複なし）を満たすサーバが {k} 台に満たない")


# ---- 名簿の版 ---------------------------------------------------------------
DIR_FIELDS = ("version", "effective_round", "policy", "members")


def dir_body(v: dict) -> bytes:
    return canon({k: v[k] for k in DIR_FIELDS})


def dir_hash(v: dict) -> str:
    return sha256_hex(dir_body(v))


def operators_of(v: dict) -> dict:
    """事業者 -> 公開鍵（1事業者1鍵）。"""
    return {m["operator"]: m["pubkey"] for m in v["members"]}


class DirectoryError(Exception):
    pass


def verify_dir_version(new: dict, prev, genesis) -> None:
    pol = new.get("policy", {})
    t, k = int(pol.get("t", 0)), int(pol.get("k", 0))
    if t < 1 or k < 2 * t + 1:
        raise DirectoryError("ポリシーが不正（t ≥ 1、k ≥ 2t+1 が必要）")
    xs = [m["x"] for m in new["members"]]
    if len(set(xs)) != len(xs) or len({m["id"] for m in new["members"]}) != len(xs):
        raise DirectoryError("サーバIDまたは評価点 x が重複している")
    if len(new["members"]) < k:
        raise DirectoryError("メンバー数が k 未満")
    distinct = pol.get("distinct", "region")
    tags = {m.get(distinct) if distinct in ("region", "operator") else m["id"] for m in new["members"]}
    if len(tags) < k:
        raise DirectoryError(f"{distinct} の異なるサーバが {len(tags)} 台しかなく、k={k} 台を選べない")
    if prev is None:
        required, quorum = operators_of(new), len(operators_of(new))
    else:
        if new["version"] != prev["version"] + 1:
            raise DirectoryError("版番号が連番でない")
        if new["effective_round"] <= prev["effective_round"]:
            raise DirectoryError("有効開始の回が前の版より前")
        if new["policy"] != genesis["policy"]:
            raise DirectoryError("t, k は初版から変更できない（断片の作り直しが必要）")
        gen = {m["id"]: m for m in genesis["members"]}
        for m in new["members"]:
            g = gen.get(m["id"])
            if g is None or g["x"] != m["x"] or g["pubkey"] != m["pubkey"]:
                raise DirectoryError(f"{m['id']}：初版にないサーバの追加は未対応（断片の再配布が必要）")
        required = operators_of(prev)
        quorum = len(required) // 2 + 1
    body = dir_body(new)
    valid = {op for op, sig in new.get("signatures", {}).items()
             if op in required and verify(required[op], body, sig)}
    if len(valid) < quorum:
        raise DirectoryError(f"承認の署名が不足（有効 {len(valid)} / 必要 {quorum}）")


def version_for_round(versions: list, rnd: int) -> dict:
    cur = versions[0]
    for v in versions:
        if v["effective_round"] <= rnd:
            cur = v
    return cur


def pending_removals(versions: list, rnd: int) -> set:
    now = {m["id"] for m in version_for_round(versions, rnd)["members"]}
    later = {m["id"] for m in versions[-1]["members"]}
    return now - later
