"""dpqctl：管理者・利用者・ベンダ・配送事業者のためのコマンドラインツール。"""
from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
import time
from datetime import date

from . import protocol as pr
from . import shamir
from .common import HttpError, Key, canon, http_json
from .client import ClientError, failures, pmap, query_params, run_query, run_redeem
from .server import name_to_field

PURPOSE_ALIAS = {"age": "age_verification", "identity": "identity_verification", "delivery": "delivery"}


class Ctx:
    def __init__(self, a):
        self.hub = (a.hub or os.environ.get("DPQ_HUB") or "http://127.0.0.1:8700").rstrip("/")
        self.home = os.path.expanduser(a.home or os.environ.get("DPQ_HOME") or "~/.dpq")
        self.admin_token = a.admin_token or os.environ.get("DPQ_ADMIN_TOKEN", "")
        self.api = (a.api or os.environ.get("DPQ_API") or "http://127.0.0.1:8710").rstrip("/")

    def key(self, kind: str, name: str, create=False) -> Key:
        path = os.path.join(self.home, kind, f"{name}.key")
        if not create and not os.path.exists(path):
            sys.exit(f"鍵がありません: {path}（先に作成してください）")
        return Key.load_or_create(path)

    def directory(self) -> dict:
        return http_json("GET", self.hub + "/directory")

    def beacon(self) -> dict:
        return http_json("GET", self.hub + "/beacon")

    def members_by_id(self) -> dict:
        vs = self.directory()["versions"]
        if not vs:
            sys.exit("名簿が未初期化です（dpqctl directory init）")
        return {m["id"]: m for m in vs[0]["members"]}, vs


def out(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


# ======================================================================= 名簿

def collect_and_post(ctx, v, signer_urls):
    rows = pmap(lambda u: http_json("POST", u + "/directory/approve", v), signer_urls)
    for u, e in failures(rows):
        print(f"  承認を得られず: {u}: {e}", file=sys.stderr)
    v["signatures"] = {r["operator"]: r["sig"] for _, r, e in rows if e is None}
    r = http_json("POST", ctx.hub + "/directory/post", v)
    pmap(lambda m: http_json("POST", m["url"] + "/directory/sync", {}), v["members"])
    return r


def cmd_directory_init(ctx, a):
    urls = [u.strip().rstrip("/") for u in a.servers.split(",") if u.strip()]
    rows = pmap(lambda u: http_json("GET", u + "/info"), urls)
    if failures(rows):
        sys.exit(f"サーバに接続できません: {failures(rows)}")
    members = sorted(({k: i[k] for k in ("id", "x", "region", "operator", "url", "pubkey")}
                      for _, i, _ in rows), key=lambda m: m["x"])
    v = {"version": 1, "effective_round": 0, "members": members,
         "policy": {"t": a.t, "k": a.k, "distinct": a.distinct}}
    r = collect_and_post(ctx, v, urls)
    print(f"名簿 第1版 を掲示しました（{len(members)}台、t={a.t}, k={a.k}, 重複禁止={a.distinct}）")
    out(r)


def _change_directory(ctx, a, remove: bool):
    d = ctx.directory()
    vs = d["versions"]
    latest, genesis = vs[-1], vs[0]
    ids = {m["id"] for m in latest["members"]}
    if remove:
        members = [m for m in latest["members"] if m["id"] != a.id]
    else:
        add = [m for m in genesis["members"] if m["id"] == a.id and m["id"] not in ids]
        members = sorted(latest["members"] + add, key=lambda m: m["x"])
    if len(members) == len(latest["members"]):
        sys.exit("変更がありません")
    eff = ctx.beacon()["round"] + a.delay
    v = {"version": latest["version"] + 1, "effective_round": eff, "members": members,
         "policy": latest["policy"]}
    signers = [m["url"] for m in latest["members"] if not (remove and m["id"] == a.id)]
    collect_and_post(ctx, v, signers)
    print(f"名簿 第{v['version']}版 を掲示しました（ラウンド{eff} から有効、{len(members)}台）")


def cmd_directory_show(ctx, a):
    d = ctx.directory()
    print(f"現在のラウンド: {d['current_round']}")
    for v in d["versions"]:
        ms = ", ".join(f"{m['id']}({m['region']})" for m in v["members"])
        print(f"第{v['version']}版 ラウンド{v['effective_round']}〜 署名{len(v.get('signatures', {}))}件 "
              f"policy={v['policy']}\n  {ms}")


def cmd_status(ctx, a):
    b = ctx.beacon()
    print(f"hub: {ctx.hub}  ラウンド {b['round']}（{b['interval']}秒間隔）")
    d = ctx.directory()
    if not d["versions"]:
        print("名簿: 未初期化")
        return
    latest = d["versions"][-1]
    in_latest = {x["id"] for x in latest["members"]}
    rows = []
    for m, info, err in pmap(lambda m: http_json("GET", m["url"] + "/info", timeout=5),
                             d["versions"][0]["members"]):
        mark = "在籍" if m["id"] in in_latest else "除外"
        if err is not None:
            rows.append(f"  {m['id']:<6} {m['region']:<6} {mark}  応答なし")
        else:
            lag = "" if info["dir_version"] == latest["version"] else "  ※名簿の同期遅れ"
            rows.append(f"  {m['id']:<6} {m['region']:<6} {mark}  利用者{info['subjects']}件 "
                        f"epoch{info['epoch']} 名簿第{info['dir_version']}版{lag}")
    print("\n".join(rows))


# ======================================================================= 登録者

def cmd_party_add(ctx, a):
    k = ctx.key("parties", a.id, create=True)
    http_json("POST", ctx.hub + "/parties", {"id": a.id, "role": a.role, "pubkey": k.public_hex},
              headers={"X-DPQ-Admin-Token": ctx.admin_token})
    print(f"{a.id}（{a.role}）を登録しました。鍵: {os.path.join(ctx.home, 'parties', a.id + '.key')}")


# ======================================================================= 利用者

def cmd_wallet_create(ctx, a):
    k = ctx.key("wallets", a.subject, create=True)
    print(f"利用者 {a.subject} の鍵を作成しました（公開鍵 {k.public_hex[:16]}…）")


def cmd_wallet_register(ctx, a):
    k = ctx.key("wallets", a.subject)
    members, vs = ctx.members_by_id()
    t = int(vs[0]["policy"]["t"])
    xs = [m["x"] for m in members.values()]
    fields = {"name_h": name_to_field(a.name)}
    n = date.fromisoformat(a.birth).toordinal()
    for i in range(pr.BIRTH_BITS):
        fields[f"birth_b{i}"] = (n >> i) & 1
    for i, val in enumerate(shamir.encode_text(a.address)):
        fields[f"addr_{i}"] = val
    per = {x: {} for x in xs}
    for f, val in fields.items():
        for x, sh in shamir.split(val, t, xs).items():
            per[x][f] = str(sh)

    def send(m):
        body = {"subject": a.subject, "user_pubkey": k.public_hex, "shares": per[m["x"]]}
        body["sig"] = k.sign(canon(body))
        return http_json("POST", m["url"] + "/register", body)
    rows = pmap(send, members.values())
    for m, e in failures(rows):
        print(f"  {m['id']}: 失敗 {e}", file=sys.stderr)
    print(f"{a.subject} を {len(rows) - len(failures(rows))}/{len(members)} 台に登録しました"
          "（各サーバには断片のみ）")


def cmd_wallet_consent(ctx, a):
    k = ctx.key("wallets", a.subject)
    purpose = PURPOSE_ALIAS.get(a.purpose, a.purpose)
    scope = {}
    if a.age is not None:
        scope["age"] = a.age
    if a.carrier:
        scope["carrier"] = a.carrier
    rnd = ctx.beacon()["round"]
    c = pr.make_consent(k, a.subject, a.vendor, purpose, scope, rnd, rounds=a.rounds, ttl=a.ttl)
    text = json.dumps(c, ensure_ascii=False, indent=2)
    if a.output:
        with open(a.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"同意トークンを {a.output} に保存（ラウンド{c['from']}〜{c['until']} 有効）")
    else:
        print(text)


def cmd_wallet_audit(ctx, a):
    k = ctx.key("wallets", a.subject)
    members, _ = ctx.members_by_id()
    t = time.time()
    body = {"subject": a.subject, "t": t, "sig": k.sign(canon({"audit": a.subject, "t": t}))}
    rows = pmap(lambda m: http_json("POST", m["url"] + "/audit", body), members.values())
    entries = sorted((e for _, r, err in rows if err is None for e in r["entries"]), key=lambda e: e["time"])
    seen = set()
    for e in entries:
        if e["event"] == "accepted":
            if e["session"] in seen:
                continue
            seen.add(e["session"])
        ts = time.strftime("%m-%d %H:%M:%S", time.localtime(e["time"]))
        detail = {k: v for k, v in e.items() if k in ("vendor", "qtype", "purpose", "reason", "selected")}
        print(f"{ts} {e['server']:<5} {e['event']:<10} {json.dumps(detail, ensure_ascii=False)}")
    if failures(rows):
        print(f"（応答なし: {[m['id'] for m, _ in failures(rows)]}）")


# ======================================================================= ベンダ

def cmd_query(ctx, a):
    key = ctx.key("parties", a.vendor)
    with open(a.consent, encoding="utf-8-sig") as f:
        consent = json.load(f)
    params = query_params(a.type, a.age, a.claimed_name, a.carrier)
    try:
        r = run_query(ctx.hub, key, a.vendor, consent, a.type, params,
                      progress=lambda m: print(m, file=sys.stderr))
    except ClientError as e:
        for k, v in (e.detail or {}).items():
            print(f"    {k}: {v}", file=sys.stderr)
        sys.exit(f"エラー: {e}")
    rec = {"subject": consent["subject"], "qtype": a.type, "params": params, **r["result"]}
    os.makedirs(os.path.join(ctx.home, "vendor-db"), exist_ok=True)
    with open(os.path.join(ctx.home, "vendor-db", f"{a.vendor}.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    out(r["result"])


# ======================================================================= 配送事業者

def cmd_redeem(ctx, a):
    key = ctx.key("parties", a.carrier)
    try:
        print(run_redeem(ctx.hub, key, a.carrier, a.token, a.servers.split(",")))
    except ClientError as e:
        for k, v in (e.detail or {}).items():
            print(f"    {k}: {v}", file=sys.stderr)
        sys.exit(f"エラー: {e}")


# ======================================================================= API 利用者（dpq-api）

def _api(ctx, method, path, body=None):
    return http_json(method, ctx.api + path, body, headers={"X-DPQ-Admin-Token": ctx.admin_token})


def _ask_password(a):
    if a.password:
        return a.password
    p1 = getpass.getpass("パスワード: ")
    if p1 != getpass.getpass("パスワード（確認）: "):
        sys.exit("パスワードが一致しません")
    return p1


def cmd_api_user_add(ctx, a):
    r = _api(ctx, "POST", "/admin/users", {"username": a.username, "password": _ask_password(a),
                                            "role": a.role, "party": a.party, "force": a.force})
    print(f"{r['username']} を登録しました（{r['role']} / {r['party']}）")


def cmd_api_user_list(ctx, a):
    for u in _api(ctx, "GET", "/admin/users")["users"]:
        last = time.strftime("%m-%d %H:%M", time.localtime(u["last_login"])) if u["last_login"] else "-"
        state = "無効" if u["disabled"] else ("ロック中" if u["locked"] else "有効")
        print(f"{u['username']:<16} {u['role']:<8} {u['party']:<12} {state:<6} "
              f"最終ログイン {last}  有効なトークン {u['active_tokens']}")


def cmd_api_user_passwd(ctx, a):
    _api(ctx, "POST", f"/admin/users/{a.username}/password", {"password": _ask_password(a)})
    print(f"{a.username} のパスワードを変更しました（発行済みのトークンは失効）")


def cmd_api_user_state(ctx, a, action):
    _api(ctx, "DELETE" if action == "delete" else "POST",
         f"/admin/users/{a.username}" + ("" if action == "delete" else f"/{action}"))
    print({"disable": f"{a.username} を無効にしました（発行済みのトークンは失効）",
           "enable": f"{a.username} を有効にしました", "delete": f"{a.username} を削除しました"}[action])


def cmd_api_log(ctx, a):
    for e in _api(ctx, "GET", f"/admin/log?limit={a.limit}")["log"]:
        ts = time.strftime("%m-%d %H:%M:%S", time.localtime(e["time"]))
        print(f"{ts} {'OK ' if e['ok'] else 'NG '} {e['action']:<16} {e['username'] or '-':<16} "
              f"{e['client'] or '-':<15} {json.dumps(e['info'], ensure_ascii=False)}")


# ======================================================================= 管理

def cmd_refresh(ctx, a):
    members, vs = ctx.members_by_id()
    rows = pmap(lambda m: http_json("GET", m["url"] + "/info"), members.values())
    if failures(rows):
        sys.exit(f"全サーバの応答が必要です。応答なし: {[m['id'] for m, _ in failures(rows)]}")
    epoch = max(i["epoch"] for _, i, _ in rows) + 1
    rows = pmap(lambda m: http_json("POST", m["url"] + "/refresh/run", {"epoch": epoch},
                                    timeout=180, headers={"X-DPQ-Admin-Token": ctx.admin_token}),
                members.values())
    if failures(rows):
        sys.exit(f"失敗: {[(m['id'], str(e)) for m, e in failures(rows)]}")
    print(f"全 {len(rows)} 台の断片を更新しました（epoch {epoch}）")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="dpqctl", description="DPQ 操作ツール")
    ap.add_argument("--hub", help="hub の URL（環境変数 DPQ_HUB）")
    ap.add_argument("--home", help="鍵などの保存先（環境変数 DPQ_HOME、既定 ~/.dpq）")
    ap.add_argument("--admin-token", help="管理トークン（環境変数 DPQ_ADMIN_TOKEN）")
    ap.add_argument("--api", help="dpq-api の URL（環境変数 DPQ_API、既定 http://127.0.0.1:8710）")
    sp = ap.add_subparsers(dest="cmd", required=True)

    p = sp.add_parser("status", help="hub と各サーバの状態")
    p.set_defaults(fn=cmd_status)

    d = sp.add_parser("directory", help="サーバ名簿の管理").add_subparsers(dest="sub", required=True)
    p = d.add_parser("init", help="名簿の初版を作る")
    p.add_argument("--servers", required=True, help="サーバURLをカンマ区切り")
    p.add_argument("--t", type=int, default=2)
    p.add_argument("--k", type=int, default=5)
    p.add_argument("--distinct", default="region", choices=["region", "operator", "none"])
    p.set_defaults(fn=cmd_directory_init)
    p = d.add_parser("show")
    p.set_defaults(fn=cmd_directory_show)
    for name, rem in (("remove", True), ("restore", False)):
        p = d.add_parser(name, help="サーバを名簿から外す" if rem else "外したサーバを戻す")
        p.add_argument("id")
        p.add_argument("--delay", type=int, default=3, help="何回先のビーコンから有効にするか")
        p.set_defaults(fn=lambda c, a, rem=rem: _change_directory(c, a, rem))

    p = sp.add_parser("party", help="ベンダ・配送事業者").add_subparsers(dest="sub", required=True)
    q = p.add_parser("add")
    q.add_argument("--id", required=True)
    q.add_argument("--role", required=True, choices=["vendor", "carrier"])
    q.set_defaults(fn=cmd_party_add)

    w = sp.add_parser("wallet", help="利用者の端末").add_subparsers(dest="sub", required=True)
    q = w.add_parser("create")
    q.add_argument("--subject", required=True)
    q.set_defaults(fn=cmd_wallet_create)
    q = w.add_parser("register")
    q.add_argument("--subject", required=True)
    q.add_argument("--name", required=True)
    q.add_argument("--birth", required=True, help="YYYY-MM-DD")
    q.add_argument("--address", required=True)
    q.set_defaults(fn=cmd_wallet_register)
    q = w.add_parser("consent")
    q.add_argument("--subject", required=True)
    q.add_argument("--vendor", required=True)
    q.add_argument("--purpose", required=True, help="age / identity / delivery")
    q.add_argument("--age", type=int)
    q.add_argument("--carrier")
    q.add_argument("--rounds", type=int, default=60)
    q.add_argument("--ttl", type=int, default=300)
    q.add_argument("-o", "--output")
    q.set_defaults(fn=cmd_wallet_consent)
    q = w.add_parser("audit")
    q.add_argument("--subject", required=True)
    q.set_defaults(fn=cmd_wallet_audit)

    p = sp.add_parser("query", help="ベンダとして照会する")
    p.add_argument("--vendor", required=True)
    p.add_argument("--consent", required=True, help="同意トークンのファイル")
    p.add_argument("--type", required=True, choices=list(pr.PURPOSE))
    p.add_argument("--age", type=int)
    p.add_argument("--claimed-name")
    p.add_argument("--carrier")
    p.set_defaults(fn=cmd_query)

    p = sp.add_parser("redeem", help="配送事業者としてトークンを引き換える")
    p.add_argument("--carrier", required=True)
    p.add_argument("--token", required=True)
    p.add_argument("--servers", required=True, help="照会結果の servers（カンマ区切り）")
    p.set_defaults(fn=cmd_redeem)

    p = sp.add_parser("admin", help="管理操作").add_subparsers(dest="sub", required=True)
    q = p.add_parser("refresh", help="全サーバの断片を更新（プロアクティブ秘密分散）")
    q.set_defaults(fn=cmd_refresh)

    p = sp.add_parser("api", help="dpq-api の利用者管理").add_subparsers(dest="sub", required=True)
    u = p.add_parser("user", help="API 利用者").add_subparsers(dest="sub2", required=True)
    q = u.add_parser("add", help="API 利用者を登録する")
    q.add_argument("--username", required=True)
    q.add_argument("--role", required=True, choices=["vendor", "carrier"])
    q.add_argument("--party", required=True, help="所属するベンダ・配送事業者のID（例 webshop）")
    q.add_argument("--password", help="省略すると対話で入力")
    q.add_argument("--force", action="store_true", help="hub の同じIDの鍵を dpq-api の鍵に置き換える")
    q.set_defaults(fn=cmd_api_user_add)
    q = u.add_parser("list")
    q.set_defaults(fn=cmd_api_user_list)
    q = u.add_parser("passwd")
    q.add_argument("username")
    q.add_argument("--password", help="省略すると対話で入力")
    q.set_defaults(fn=cmd_api_user_passwd)
    for action in ("disable", "enable", "delete"):
        q = u.add_parser(action)
        q.add_argument("username")
        q.set_defaults(fn=lambda c, a, action=action: cmd_api_user_state(c, a, action))
    q = p.add_parser("log", help="API の操作記録")
    q.add_argument("--limit", type=int, default=50)
    q.set_defaults(fn=cmd_api_log)

    a = ap.parse_args(argv)
    try:
        a.fn(Ctx(a), a)
    except (HttpError, ValueError, ClientError) as e:
        sys.exit(f"エラー: {e}")
    except OSError as e:
        sys.exit(f"接続エラー: {e}")


if __name__ == "__main__":
    main()
