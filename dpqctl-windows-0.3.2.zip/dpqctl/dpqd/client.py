"""ベンダの照会と配送事業者の引き換えの手順（dpqctl と dpq-api で共用）。

どちらも「鍵を持つ側」が実行する処理で、結果を dict で返す。失敗は ClientError を送出する。
"""
from __future__ import annotations

import os
import threading
import time

from . import protocol as pr
from . import shamir
from .common import HttpError, Key, canon, http_json


class ClientError(Exception):
    """照会・引き換えの失敗。status は HTTP API で返すときのステータス。"""

    def __init__(self, message: str, status: int = 400, detail=None):
        super().__init__(message)
        self.status, self.detail = status, detail


def pmap(fn, items):
    """items を並列に処理し、[(item, 結果, 例外)] を items の順で返す。"""
    items = list(items)
    res = [None] * len(items)
    errs = [None] * len(items)

    def run(i):
        try:
            res[i] = fn(items[i])
        except Exception as e:  # noqa: BLE001
            errs[i] = e
    th = [threading.Thread(target=run, args=(i,)) for i in range(len(items))]
    for t in th:
        t.start()
    for t in th:
        t.join()
    return list(zip(items, res, errs))


def failures(rows):
    return [(it, e) for it, _, e in rows if e is not None]


def locate_faulty(outs: dict, t: int):
    for x in outs:
        rest = {k: v for k, v in outs.items() if k != x}
        if shamir.is_consistent(rest, t):
            return x
    return None


def query_params(qtype: str, age=None, claimed_name=None, carrier=None) -> dict:
    if qtype == "age_over":
        if age is None:
            raise ClientError("age_over には age が必要")
        return {"age": int(age)}
    if qtype == "name_match":
        if not claimed_name:
            raise ClientError("name_match には claimed_name が必要")
        return {"claimed_name": str(claimed_name)}
    if qtype == "delivery_token":
        if not carrier:
            raise ClientError("delivery_token には carrier が必要")
        return {"carrier": str(carrier)}
    raise ClientError(f"type は {', '.join(pr.PURPOSE)} のいずれか")


def run_query(hub: str, key: Key, vendor: str, consent: dict, qtype: str, params: dict,
              progress=lambda msg: None, timeout: float = 60.0) -> dict:
    """照会を1件実行する。戻り値：{"result": …, "selected": […], "round": n, "elapsed": 秒}"""
    if not isinstance(consent, dict) or "subject" not in consent:
        raise ClientError("同意トークンの形式が不正")
    if consent.get("vendor") != vendor:
        raise ClientError(f"この同意トークンは {consent.get('vendor')} 宛てで、{vendor} では使えない", 403)
    b = http_json("GET", hub + "/beacon")
    rnd = b["round"] + 1
    d = http_json("GET", hub + "/directory")
    if not d["versions"]:
        raise ClientError("名簿が未初期化", 503)
    ver = pr.version_for_round(d["versions"], rnd)
    req = {"vendor": vendor, "subject": consent["subject"], "qtype": qtype, "params": params,
           "consent": consent, "round": rnd, "dir_version": ver["version"], "dir_hash": pr.dir_hash(ver),
           "nonce": os.urandom(16).hex()}
    digest = pr.request_digest(req)
    cid = pr.consent_id(consent)
    http_json("POST", hub + "/board/post",
              {"digest": digest, "consent_id": cid, "poster": vendor,
               "sig": key.sign(pr.board_post_message(digest, cid))})
    progress(f"[1] 依頼書の指紋を掲示（ラウンド{rnd} のビーコンを使用）")
    deadline = time.time() + timeout
    while http_json("GET", hub + "/beacon")["round"] < rnd:
        if time.time() > deadline:
            raise ClientError("ビーコンが進まない", 504)
        time.sleep(0.3)
    req["beacon_value"] = http_json("GET", f"{hub}/beacon/{rnd}")["value"]
    pol = ver["policy"]
    req["selected"] = pr.select_servers(ver["members"], req["beacon_value"], digest, int(pol["k"]),
                                        pol.get("distinct", "region"))
    req["vendor_sig"] = key.sign(digest.encode())
    progress(f"[2] 選定されたサーバ: {req['selected']}")
    members = {m["id"]: m for m in ver["members"]}
    sel = [members[i] for i in req["selected"]]
    rows = pmap(lambda m: http_json("POST", m["url"] + "/session/open", req), sel)
    if failures(rows):
        detail = {m["id"]: f"{'拒否' if isinstance(e, HttpError) else '接続できない'}: {e}"
                  for m, e in failures(rows)}
        rejected = any(isinstance(e, HttpError) for _, e in failures(rows))
        raise ClientError("選定されたサーバが照会を受け付けなかった", 403 if rejected else 502, detail)
    sid = rows[0][1]["sid"]
    t0 = time.time()
    pmap(lambda m: http_json("POST", m["url"] + "/session/run", {"sid": sid}), sel)
    outs = {}
    while len(outs) < len(sel):
        if time.time() > deadline:
            raise ClientError("秘密計算がタイムアウト", 504)
        for m in sel:
            if m["x"] in outs:
                continue
            r = http_json("GET", f"{m['url']}/session/{sid}/output")
            if r["error"]:
                raise ClientError(f"{m['id']} で計算失敗: {r['error']}", 502)
            if r["ready"]:
                outs[m["x"]] = int(r["value"])
        time.sleep(0.05)
    elapsed = round(time.time() - t0, 2)
    progress(f"[3] 秘密計算 完了（{elapsed:.2f} 秒）")
    t = int(pol["t"])
    if qtype == "delivery_token":
        if len(set(outs.values())) != 1:
            raise ClientError("サーバ間でトークンが一致しない（改ざんの疑い）", 502)
        result = {"token": f"{next(iter(outs.values())):030x}", "servers": req["selected"]}
    else:
        if not shamir.is_consistent(outs, t):
            bad = locate_faulty(outs, t)
            who = next((m["id"] for m in sel if m["x"] == bad), None)
            raise ClientError(f"出力断片の不整合を検知（改ざんの疑い）。推定: {who}", 502)
        v = shamir.reconstruct(outs)
        result = {"over": v == 1} if qtype == "age_over" else {"match": v == 0}
    return {"result": result, "selected": req["selected"], "round": rnd, "elapsed": elapsed}


def run_redeem(hub: str, key: Key, carrier: str, token: str, servers: list) -> str:
    """配送トークンを引き換え、復元した住所を返す。"""
    vs = http_json("GET", hub + "/directory")["versions"]
    if not vs:
        raise ClientError("名簿が未初期化", 503)
    members = {m["id"]: m for m in vs[0]["members"]}
    t = int(vs[0]["policy"]["t"])
    unknown = [s for s in servers if s not in members]
    if unknown:
        raise ClientError(f"名簿にないサーバ: {unknown}")
    ts = time.time()
    body = {"carrier": carrier, "token": token, "t": ts,
            "sig": key.sign(canon({"carrier": carrier, "token": token, "t": ts}))}
    rows = pmap(lambda m: http_json("POST", m["url"] + "/redeem", body), [members[i] for i in servers])
    if failures(rows):
        detail = {m["id"]: str(e) for m, e in failures(rows)}
        rejected = any(isinstance(e, HttpError) for _, e in failures(rows))
        raise ClientError("引き換えを受け付けなかったサーバがある", 403 if rejected else 502, detail)
    shares = {m["x"]: {f: int(v) for f, v in r["shares"].items()} for m, r, _ in rows}
    fields = sorted(next(iter(shares.values())), key=lambda f: int(f.split("_")[1]))
    vals = []
    for f in fields:
        pts = {x: s[f] for x, s in shares.items()}
        if not shamir.is_consistent(pts, t):
            raise ClientError("住所断片の不整合を検知", 502)
        vals.append(shamir.reconstruct(pts))
    return shamir.decode_text(vals)
