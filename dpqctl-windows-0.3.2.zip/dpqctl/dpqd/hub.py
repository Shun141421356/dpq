"""dpq-hub：公開基盤（ランダムビーコン・事前掲示板・名簿台帳・ベンダ等の公開鍵登録）。

本番ではそれぞれを複数事業者で分散運用する想定だが、試作では1つのデーモンにまとめている。
hub は秘密を何も持たない（ビーコンの種を除く）。名簿の版は各サーバ自身も署名を検証する。
"""
from __future__ import annotations

import argparse
import os
import secrets
import time

from . import protocol as pr
from .common import (VERSION, ApiError, Router, load_config, log, require_admin, serve,
                     setup_logging, strip_meta, verify)
from .store import Store

CHECKPOINT = 1000
CLOCK_SANE_AFTER = 1767225600  # 2026-01-01。これより前なら時計が未同期とみなす


class Beacon:
    """ハッシュチェーン型ビーコン。時刻から現在の回が決まり、自動で進む。"""

    def __init__(self, store: Store, data_dir: str, interval: float, length: int):
        self.interval, self.length = interval, length
        seed_path = os.path.join(data_dir, "beacon.seed")
        if not os.path.exists(seed_path):
            if time.time() < CLOCK_SANE_AFTER:
                raise SystemExit("時計が合っていないため、ビーコンを初期化しない"
                                 "（timedatectl で時刻の同期を確認してから起動する）")
            fd = os.open(seed_path, os.O_WRONLY | os.O_CREAT, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(secrets.token_hex(32))
            store.set_meta("beacon_start", time.time())
            store.set_meta("beacon_length", length)
        with open(seed_path) as f:
            seed = bytes.fromhex(f.read().strip())
        self.start = store.get_meta("beacon_start")
        self.length = store.get_meta("beacon_length", length)
        log.info("ビーコンのチェーンを計算中（長さ %d）…", self.length)
        t0 = time.time()
        self.cp = {self.length: seed}
        v = seed
        for i in range(self.length - 1, -1, -1):
            v = pr.H(v)
            if i % CHECKPOINT == 0:
                self.cp[i] = v
        self.anchor = self.cp[0]
        log.info("ビーコン準備完了（%.1f 秒）anchor=%s…", time.time() - t0, self.anchor.hex()[:16])

    @property
    def round(self) -> int:
        r = int((time.time() - self.start) / self.interval)
        if r >= self.length:
            raise ApiError(503, "ビーコンのチェーンを使い切った（hub の再初期化が必要）")
        return r

    def value(self, i: int) -> bytes:
        if i > self.round:
            raise ApiError(404, f"ラウンド {i} はまだ公開されていない")
        j = min(((i + CHECKPOINT - 1) // CHECKPOINT) * CHECKPOINT, self.length)
        if j not in self.cp:
            j = self.length
        return pr.chain_down(self.cp[j], j - i)


class Hub:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.data_dir = cfg.get("data_dir", "/var/lib/dpq/hub")
        os.makedirs(self.data_dir, exist_ok=True)
        self.store = Store(os.path.join(self.data_dir, "hub.db"))
        self.admin_token = cfg.get("admin_token", "")
        if not self.admin_token or self.admin_token == "CHANGE_ME":
            log.warning("admin_token が未設定です。ベンダ等の登録ができません")
        self.beacon = Beacon(self.store, self.data_dir, float(cfg.get("beacon_interval", "3")),
                             int(cfg.get("beacon_length", "3000000")))
        self.router = Router()
        r = self.router.add
        r("GET", "/health", lambda b: {"ok": True, "version": VERSION})
        r("GET", "/beacon", self.get_beacon)
        r("GET", r"/beacon/(\d+)", self.get_beacon_round)
        r("POST", "/board/post", self.board_post)
        r("GET", r"/board/entry/([0-9a-f]{64})", self.board_entry)
        r("GET", "/board/count", self.board_count)
        r("GET", "/directory", self.get_directory)
        r("POST", "/directory/post", self.post_directory)
        r("POST", "/parties", self.register_party)
        r("GET", "/parties", self.list_parties)
        r("GET", r"/parties/([\w.\-]+)", self.get_party)

    # ---- ビーコン ----
    def get_beacon(self, b):
        rnd = self.beacon.round
        return {"round": rnd, "value": self.beacon.value(rnd).hex(), "anchor": self.beacon.anchor.hex(),
                "interval": self.beacon.interval, "start": self.beacon.start}

    def get_beacon_round(self, b, rnd):
        rnd = int(rnd)
        return {"round": rnd, "value": self.beacon.value(rnd).hex()}

    # ---- 掲示板 ----
    def board_post(self, b):
        b = strip_meta(b)
        digest, cid, poster, sig = b["digest"], b["consent_id"], b["poster"], b["sig"]
        party = self._party(poster)
        if not verify(party["pubkey"], pr.board_post_message(digest, cid), sig):
            raise ApiError(403, "掲示者の署名が不正")
        rnd = self.beacon.round
        st = self.store
        with st.tx():
            st.db.execute("DELETE FROM board WHERE round < ?", (rnd - (pr.MAX_CONSENT_ROUNDS + pr.ROUND_MARGIN),))
            st.db.execute("INSERT OR IGNORE INTO board(digest, consent_id, poster, round, posted_at) "
                          "VALUES (?, ?, ?, ?, ?)", (digest, cid, poster, rnd, time.time()))
        row = st.q("SELECT round FROM board WHERE digest=?", (digest,))
        return {"round": row[0][0]}

    def board_entry(self, b, digest):
        row = self.store.q("SELECT consent_id, poster, round FROM board WHERE digest=?", (digest,))
        if not row:
            raise ApiError(404, "掲示されていない")
        cid, poster, rnd = row[0]
        return {"digest": digest, "consent_id": cid, "poster": poster, "round": rnd}

    def board_count(self, b):
        q = b.get("_query", {})
        n = self.store.q("SELECT COUNT(*) FROM board WHERE consent_id=? AND poster=?",
                         (q.get("consent_id", ""), q.get("vendor", "")))[0][0]
        return {"count": n}

    # ---- 名簿 ----
    def get_directory(self, b):
        return {"versions": self.store.directory_versions(), "current_round": self.beacon.round}

    def post_directory(self, b):
        v = strip_meta(b)
        versions = self.store.directory_versions()
        prev = versions[-1] if versions else None
        genesis = versions[0] if versions else None
        if prev is not None and v.get("effective_round", 0) < self.beacon.round + pr.DIR_MIN_DELAY:
            raise ApiError(400, "有効開始の回が近すぎる（全サーバが同期できる猶予がない）")
        try:
            pr.verify_dir_version(v, prev, genesis)
        except (pr.DirectoryError, KeyError, ValueError) as e:
            raise ApiError(400, f"名簿の版を受理できない: {e}")
        self.store.add_directory_version(v)
        log.info("名簿 第%d版 を掲示（ラウンド%d から有効）", v["version"], v["effective_round"])
        return {"ok": True, "hash": pr.dir_hash(v)}

    # ---- ベンダ・配送事業者の公開鍵 ----
    def register_party(self, b):
        require_admin(b, self.admin_token)
        pid, role, pub = b["id"], b["role"], b["pubkey"]
        if role not in ("vendor", "carrier"):
            raise ApiError(400, "role は vendor か carrier")
        self.store.x("INSERT OR REPLACE INTO parties(id, role, pubkey) VALUES (?, ?, ?)", (pid, role, pub))
        log.info("登録: %s (%s)", pid, role)
        return {"ok": True}

    def _party(self, pid):
        row = self.store.q("SELECT role, pubkey FROM parties WHERE id=?", (pid,))
        if not row:
            raise ApiError(404, f"未登録: {pid}")
        return {"id": pid, "role": row[0][0], "pubkey": row[0][1]}

    def get_party(self, b, pid):
        return self._party(pid)

    def list_parties(self, b):
        return {"parties": [{"id": i, "role": r, "pubkey": p}
                            for i, r, p in self.store.q("SELECT id, role, pubkey FROM parties")]}


def main(argv=None):
    ap = argparse.ArgumentParser(prog="dpq-hub", description="DPQ 公開基盤デーモン")
    ap.add_argument("--config", default="/etc/dpq/hub.conf")
    a = ap.parse_args(argv)
    cfg = load_config(a.config, "hub")
    setup_logging(cfg.get("log_level", "INFO"))
    hub = Hub(cfg)
    serve(hub.router, cfg.get("listen", "0.0.0.0:8700"), "hub").serve_forever()


if __name__ == "__main__":
    main()
