"""共通部品：正規化JSON、Ed25519署名、HTTPの送受信、設定ファイル、ログ。"""
from __future__ import annotations

import configparser
import hashlib
import json
import logging
import os
import re
import hmac
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (Ed25519PrivateKey,
                                                               Ed25519PublicKey)

VERSION = "0.3.2"
MAX_BODY = 4 * 1024 * 1024
log = logging.getLogger("dpq")


def setup_logging(level: str = "INFO"):
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")


# ---- 正規化と署名 -----------------------------------------------------------

def canon(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


class Key:
    """Ed25519 の鍵ペア。秘密鍵は 32 バイトの生データを16進でファイルに保存する。"""

    def __init__(self, priv: Ed25519PrivateKey):
        self._priv = priv

    @classmethod
    def generate(cls) -> "Key":
        return cls(Ed25519PrivateKey.generate())

    @classmethod
    def from_hex(cls, h: str) -> "Key":
        return cls(Ed25519PrivateKey.from_private_bytes(bytes.fromhex(h)))

    @classmethod
    def load_or_create(cls, path: str) -> "Key":
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                return cls.from_hex(f.read().strip())
        k = cls.generate()
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(k.private_hex())
        return k

    def private_hex(self) -> str:
        return self._priv.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                                        serialization.NoEncryption()).hex()

    @property
    def public_hex(self) -> str:
        return self._priv.public_key().public_bytes(serialization.Encoding.Raw,
                                                    serialization.PublicFormat.Raw).hex()

    def sign(self, msg: bytes) -> str:
        return self._priv.sign(msg).hex()


def verify(pub_hex: str, msg: bytes, sig_hex: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub_hex)).verify(bytes.fromhex(sig_hex), msg)
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


# ---- HTTP クライアント ------------------------------------------------------

class HttpError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(f"HTTP {status}: {message}")
        self.status, self.message = status, message


def http_json(method: str, url: str, body=None, timeout: float = 30.0, headers=None):
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode()
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read()).get("error", e.reason)
        except Exception:  # noqa: BLE001
            msg = str(e.reason)
        raise HttpError(e.code, msg) from None


# ---- HTTP サーバ（簡易ルーター） --------------------------------------------

class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


class Router:
    def __init__(self):
        self.routes: list[tuple[str, re.Pattern, object]] = []

    def add(self, method: str, pattern: str, fn):
        self.routes.append((method, re.compile("^" + pattern + "$"), fn))

    def dispatch(self, method: str, path: str, body):
        for m, pat, fn in self.routes:
            if m == method:
                mt = pat.match(path)
                if mt:
                    return fn(body, *mt.groups())
        raise ApiError(404, "not found")


def serve(router: Router, listen: str, name: str, auth_header_value=None):
    host, port = listen.rsplit(":", 1)

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = f"dpq-{name}/{VERSION}"

        def log_message(self, fmt, *args):  # アクセスログは DEBUG のみ
            log.debug("%s %s", self.address_string(), fmt % args)

        def _handle(self, method):
            body = None
            n = int(self.headers.get("Content-Length") or 0)
            try:
                if n > MAX_BODY:
                    raise ApiError(413, "本文が大きすぎる")
                if n:
                    try:
                        body = json.loads(self.rfile.read(n).decode("utf-8-sig"))
                    except ValueError:
                        raise ApiError(400, "本文が JSON として読めない") from None
                if body is None:
                    body = {}
                if not isinstance(body, dict):
                    raise ApiError(400, "本文は JSON オブジェクトにする")
                body["_headers"] = {k.lower(): v for k, v in self.headers.items()}
                body["_client"] = self.client_address[0]
                path = self.path.split("?", 1)
                if len(path) == 2:
                    body["_query"] = dict(urllib.parse.parse_qsl(path[1]))
                out = router.dispatch(method, path[0], body)
                code = 200
            except ApiError as e:
                out, code = {"error": str(e)}, e.status
            except Exception as e:  # noqa: BLE001
                log.exception("内部エラー")
                out, code = {"error": f"internal error: {e}"}, 500
            raw = json.dumps(out, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            self._handle("GET")

        def do_POST(self):
            self._handle("POST")

        def do_DELETE(self):
            self._handle("DELETE")

    httpd = ThreadingHTTPServer((host, int(port)), Handler)
    httpd.daemon_threads = True
    log.info("%s を %s で待ち受け開始", name, listen)
    return httpd


def require_admin(body: dict, token: str):
    if not token or token == "CHANGE_ME":
        raise ApiError(403, "管理トークンが未設定（設定ファイルの admin_token を変更してください）")
    if not hmac.compare_digest(body.get("_headers", {}).get("x-dpq-admin-token", "").encode(), token.encode()):
        raise ApiError(403, "管理トークンが不正")


def strip_meta(body: dict) -> dict:
    return {k: v for k, v in body.items() if not k.startswith("_")}


# ---- 設定ファイル -----------------------------------------------------------

def load_config(path: str, section: str) -> dict:
    cp = configparser.ConfigParser()
    if not cp.read(path, encoding="utf-8"):
        raise SystemExit(f"設定ファイルを読めません: {path}")
    if section not in cp:
        raise SystemExit(f"設定ファイルに [{section}] がありません: {path}")
    out = dict(cp[section])
    for s in cp.sections():
        if s != section:
            out.update({f"{s}.{k}": v for k, v in cp[s].items()})
    return out

