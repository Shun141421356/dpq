"""秘密計算（BGW方式）。通信路は外から渡す（サーバ間HTTP）。"""
from __future__ import annotations

import secrets

from . import shamir
from .field import P, lagrange_coeffs


class Party:
    """1セッションにおける1サーバの計算主体。

    net は send(dst_x, tag, value) と recv(src_x, tag) -> value を持つオブジェクト。
    """

    def __init__(self, x: int, peers: list, t: int, net):
        if len(peers) < 2 * t + 1:
            raise ValueError("掛け算には 2t+1 台以上が必要")
        self.x, self.peers, self.t, self.net = x, peers, t, net
        self._ctr = 0
        self._lam = lagrange_coeffs(peers, 0)

    def _tag(self, name: str) -> str:
        self._ctr += 1
        return f"{name}#{self._ctr}"

    def _exchange(self, tag: str, subs: dict) -> dict:
        for x in self.peers:
            if x != self.x:
                self.net.send(x, tag, subs[x])
        got = {self.x: subs[self.x]}
        for x in self.peers:
            if x != self.x:
                got[x] = self.net.recv(x, tag)
        return got

    def mul(self, a: int, b: int) -> int:
        tag = self._tag("mul")
        got = self._exchange(tag, shamir.split(a * b % P, self.t, self.peers))
        return sum(self._lam[x] * got[x] for x in self.peers) % P

    def random(self) -> int:
        tag = self._tag("rand")
        got = self._exchange(tag, shamir.split(secrets.randbelow(P), self.t, self.peers))
        return sum(got.values()) % P


def less_than_public(party: Party, bits: list, c: int) -> int:
    """断片化されたビット列（LSBから）と公開定数 c について [x < c] の断片。"""
    L = len(bits)
    if c >> L:
        return 1
    lt, prefix = 0, None  # prefix: 上位桁がすべて一致しているか（None は定数1）
    for i in range(L - 1, -1, -1):
        ci, xi = (c >> i) & 1, bits[i]
        if ci == 1:
            not_xi = (1 - xi) % P
            lt = (lt + (not_xi if prefix is None else party.mul(prefix, not_xi))) % P
        if i > 0:
            eq = xi if ci == 1 else (1 - xi) % P
            prefix = eq if prefix is None else party.mul(prefix, eq)
    return lt


def masked_difference(party: Party, x: int, public: int) -> int:
    """r * (x - public) の断片。0 なら一致、それ以外は一様乱数。"""
    return party.mul(party.random(), (x - public) % P)
