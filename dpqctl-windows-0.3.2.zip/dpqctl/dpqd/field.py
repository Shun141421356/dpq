"""有限体 GF(P) 上の演算。P はメルセンヌ素数 2^127 - 1。"""
from __future__ import annotations

P = (1 << 127) - 1


def inv(a: int) -> int:
    a %= P
    if a == 0:
        raise ZeroDivisionError("0 の逆元は存在しない")
    return pow(a, P - 2, P)


def lagrange_coeffs(xs: list[int], at: int = 0) -> dict[int, int]:
    """点 xs における値から f(at) を得るためのラグランジュ係数。"""
    coeffs = {}
    for i in xs:
        num, den = 1, 1
        for j in xs:
            if j == i:
                continue
            num = num * (at - j) % P
            den = den * (i - j) % P
        coeffs[i] = num * inv(den) % P
    return coeffs


def interpolate(points: dict[int, int], at: int = 0) -> int:
    lam = lagrange_coeffs(list(points), at)
    return sum(lam[x] * y for x, y in points.items()) % P
