"""シャミアの秘密分散（次数 t の多項式。t+1 個の断片で復元、t 個以下では何も分からない）。"""
from __future__ import annotations

import secrets

from .field import P, interpolate


def split(secret: int, t: int, xs: list[int]) -> dict[int, int]:
    coeffs = [secret % P] + [secrets.randbelow(P) for _ in range(t)]
    out = {}
    for x in xs:
        y = 0
        for c in reversed(coeffs):
            y = (y * x + c) % P
        out[x] = y
    return out


def reconstruct(shares: dict[int, int]) -> int:
    return interpolate(shares, 0)


def is_consistent(shares: dict[int, int], t: int) -> bool:
    """全断片が同じ次数 t の多項式上にあるか（改ざん検知に使う）。"""
    xs = sorted(shares)
    if len(xs) <= t + 1:
        return True
    base = {x: shares[x] for x in xs[: t + 1]}
    return all(interpolate(base, x) == shares[x] for x in xs[t + 1:])


# ---- 文字列 <-> 体の元 ------------------------------------------------------
CHUNK = 15  # 15 バイト < 2^127


def encode_text(s: str) -> list[int]:
    b = s.encode("utf-8")
    return [len(b)] + [int.from_bytes(b[i:i + CHUNK], "big") for i in range(0, len(b), CHUNK)]


def decode_text(vals: list[int]) -> str:
    n, chunks = vals[0], vals[1:]
    out = b""
    for i, v in enumerate(chunks):
        size = min(CHUNK, n - i * CHUNK)
        out += int(v).to_bytes(size, "big")
    return out.decode("utf-8")
