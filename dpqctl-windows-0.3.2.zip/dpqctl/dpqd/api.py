"""dpq-api：ベンダの照会と配送事業者の引き換えを HTTP API（curl など）で行うための窓口。

- 管理者が事前に API 利用者（ユーザー名・パスワード・役・所属）を登録する
- 登録済みの利用者だけが、ユーザー名とパスワードで API トークンを払い出せる
- API トークンを Authorization: Bearer で付けて /v1/query・/v1/redeem を呼ぶ

ベンダ・配送事業者の署名鍵は dpq-api が預かる（data_dir/parties/）。
利用者（個人）の鍵と生データは扱わない。登録と同意は従来どおり利用者の端末（dpqctl wallet）で行う。
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time

from . import protocol as pr
from .client import ClientError, query_params, run_query, run_redeem
from .common import (VERSION, ApiError, HttpError, Key, Router, http_json, load_config, log,
                     require_admin, serve, setup_logging, strip_meta)
from .store import Store

SCHEMA = """
CREATE TABLE IF NOT EXISTS api_users (
  username TEXT PRIMARY KEY, pw_salt TEXT NOT NULL, pw_hash TEXT NOT NULL,
  role TEXT NOT NULL, party TEXT NOT NULL, disabled INTEGER NOT NULL DEFAULT 0,
  created REAL NOT NULL, last_login REAL, failures INTEGER NOT NULL DEFAULT 0, locked_until REAL);
CREATE TABLE IF NOT EXISTS api_tokens (
  token_hash TEXT PRIMARY KEY, username TEXT NOT NULL, label TEXT,
  issued REAL NOT NULL, expires REAL NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS api_tokens_user ON api_tokens (username);
CREATE TABLE IF NOT EXISTS api_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, time REAL NOT NULL, username TEXT, client TEXT,
  action TEXT NOT NULL, ok INTEGER NOT NULL, info TEXT);
"""

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,64}$")
PARTY_RE = re.compile(r"^[\w.\-]{1,64}$")
ROLES = ("vendor", "carrier")
MIN_PASSWORD = 8
TOKEN_PREFIX = "dpq_"


def hash_password(password: str, salt: bytes) -> str:
    return hashlib.scrypt(password.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32).hex()


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


class Api:
    def __init__(self, cfg: dict):
        self.hub = cfg.get("hub_url", "http://127.0.0.1:8700").rstrip("/")
        self.data_dir = cfg.get("data_dir", "/var/lib/dpq/api")
        os.makedirs(self.data_dir, exist_ok=True)
        self.store = Store(os.path.join(self.data_dir, "api.db"))
        self.store.db.executescript(SCHEMA)
        self.admin_token = cfg.get("admin_token", "")
        if not self.admin_token or self.admin_token == "CHANGE_ME":
            log.warning("admin_token が未設定です。API 利用者の登録ができません")
        self.admin_allow = {a.strip() for a in cfg.get("admin_allow", "127.0.0.1, ::1").split(",") if a.strip()}
        self.token_ttl = int(cfg.get("token_ttl", "3600"))
        self.max_token_ttl = int(cfg.get("max_token_ttl", "86400"))
        self.max_failures = int(cfg.get("login_max_failures", "5"))
        self.lock_seconds = int(cfg.get("login_lock_seconds", "300"))
        self._dummy_salt = secrets.token_bytes(16)
        self._key_lock = threading.Lock()
        self.router = Router()
        r = self.router.add
        r("GET", "/health", lambda b: {"ok": True, "version": VERSION})
        r("POST", "/auth/token", self.issue_token)
        r("POST", "/auth/revoke", self.revoke_token)
        r("GET", "/v1/me", self.me)
        r("GET", "/v1/status", self.status)
        r("POST", "/v1/query", self.query)
        r("POST", "/v1/redeem", self.redeem)
        r("GET", "/v1/records", self.records)
        r("POST", "/admin/users", self.admin_add_user)
        r("GET", "/admin/users", self.admin_list_users)
        r("POST", r"/admin/users/([A-Za-z0-9_.\-]+)/password", self.admin_set_password)
        r("POST", r"/admin/users/([A-Za-z0-9_.\-]+)/disable", lambda b, u: self.admin_set_disabled(b, u, 1))
        r("POST", r"/admin/users/([A-Za-z0-9_.\-]+)/enable", lambda b, u: self.admin_set_disabled(b, u, 0))
        r("DELETE", r"/admin/users/([A-Za-z0-9_.\-]+)", self.admin_delete_user)
        r("GET", "/admin/log", self.admin_log)

    # ================================================================ 共通
    def audit(self, b, username, action, ok, **info):
        self.store.x("INSERT INTO api_log(time, username, client, action, ok, info) VALUES (?, ?, ?, ?, ?, ?)",
                     (time.time(), username, b.get("_client"), action, int(ok),
                      json.dumps(info, ensure_ascii=False)))

    def auth(self, b, role=None) -> dict:
        """Authorization: Bearer <API トークン> を検証し、利用者の情報を返す。"""
        h = b.get("_headers", {}).get("authorization", "")
        if not h.lower().startswith("bearer "):
            raise ApiError(401, "Authorization: Bearer <API トークン> が必要")
        tok = h[7:].strip()
        row = self.store.q(
            "SELECT t.username, t.expires, t.revoked, u.role, u.party, u.disabled FROM api_tokens t "
            "JOIN api_users u ON u.username = t.username WHERE t.token_hash=?", (token_hash(tok),))
        if not row:
            raise ApiError(401, "API トークンが無効")
        username, expires, revoked, urole, party, disabled = row[0]
        if revoked:
            raise ApiError(401, "API トークンは失効済み")
        if expires < time.time():
            raise ApiError(401, "API トークンの有効期限切れ（/auth/token で取り直す）")
        if disabled:
            raise ApiError(403, "この利用者は無効化されている")
        if role and urole != role:
            raise ApiError(403, f"この操作は {role} の利用者のみ（あなたは {urole}）")
        return {"username": username, "role": urole, "party": party, "expires": expires,
                "token_hash": token_hash(tok)}

    def admin(self, b):
        if b.get("_client") not in self.admin_allow:
            raise ApiError(403, f"管理操作は {sorted(self.admin_allow)} からのみ（api.conf の admin_allow）")
        require_admin(b, self.admin_token)

    def party_key(self, party: str) -> Key:
        path = os.path.join(self.data_dir, "parties", f"{party}.key")
        if not os.path.exists(path):
            raise ApiError(500, f"{party} の鍵がない（利用者を登録し直す）")
        return Key.load_or_create(path)

    # ================================================================ トークン
    def issue_token(self, b):
        username, password = str(b.get("username", "")), str(b.get("password", ""))
        now = time.time()
        row = self.store.q("SELECT pw_salt, pw_hash, disabled, failures, locked_until FROM api_users "
                           "WHERE username=?", (username,)) if USERNAME_RE.match(username) else []
        if not row:
            hash_password(password, self._dummy_salt)  # 利用者の有無を応答時間で悟られないように
            self.audit(b, username[:64], "login", False, reason="unknown user")
            raise ApiError(401, "ユーザー名またはパスワードが違う")
        salt, pw_hash, disabled, fails, locked_until = row[0]
        if locked_until and locked_until > now:
            self.audit(b, username, "login", False, reason="locked")
            raise ApiError(429, f"ログイン失敗が続いたためロック中（あと {int(locked_until - now)} 秒）")
        if not hmac.compare_digest(hash_password(password, bytes.fromhex(salt)), pw_hash):
            fails += 1
            lock = now + self.lock_seconds if fails >= self.max_failures else None
            self.store.x("UPDATE api_users SET failures=?, locked_until=? WHERE username=?",
                         (0 if lock else fails, lock, username))
            self.audit(b, username, "login", False, reason="bad password", locked=bool(lock))
            raise ApiError(401, "ユーザー名またはパスワードが違う")
        if disabled:
            self.audit(b, username, "login", False, reason="disabled")
            raise ApiError(403, "この利用者は無効化されている")
        ttl = int(b.get("ttl") or self.token_ttl)
        if not 60 <= ttl <= self.max_token_ttl:
            raise ApiError(400, f"ttl は 60〜{self.max_token_ttl} 秒")
        tok = TOKEN_PREFIX + secrets.token_urlsafe(32)
        with self.store.tx():
            self.store.db.execute("DELETE FROM api_tokens WHERE expires < ?", (now - 86400,))
            self.store.db.execute(
                "INSERT INTO api_tokens(token_hash, username, label, issued, expires) VALUES (?, ?, ?, ?, ?)",
                (token_hash(tok), username, str(b.get("label", ""))[:100], now, now + ttl))
            self.store.db.execute("UPDATE api_users SET failures=0, locked_until=NULL, last_login=? "
                                  "WHERE username=?", (now, username))
        self.audit(b, username, "login", True, ttl=ttl)
        return {"token": tok, "token_type": "Bearer", "expires_in": ttl,
                "expires_at": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(now + ttl))}

    def revoke_token(self, b):
        u = self.auth(b)
        if b.get("all"):
            self.store.x("UPDATE api_tokens SET revoked=1 WHERE username=?", (u["username"],))
        else:
            self.store.x("UPDATE api_tokens SET revoked=1 WHERE token_hash=?", (u["token_hash"],))
        self.audit(b, u["username"], "revoke", True, all=bool(b.get("all")))
        return {"ok": True, "revoked": "all" if b.get("all") else "this"}

    def me(self, b):
        u = self.auth(b)
        return {"username": u["username"], "role": u["role"], "party": u["party"],
                "token_expires_in": int(u["expires"] - time.time())}

    def status(self, b):
        self.auth(b)
        beacon = http_json("GET", self.hub + "/beacon")
        vs = http_json("GET", self.hub + "/directory")["versions"]
        return {"beacon_round": beacon["round"], "beacon_interval": beacon["interval"],
                "directory_version": vs[-1]["version"] if vs else None,
                "servers": [m["id"] for m in (pr.version_for_round(vs, beacon["round"])["members"] if vs else [])]}

    # ================================================================ 照会・引き換え
    def query(self, b):
        u = self.auth(b, "vendor")
        q = b.get("_query", {})
        if "consent" in b:  # 形式1：{"consent": {...}, "type": ..., "age": ...}
            consent, src = b["consent"], b
        else:               # 形式2：本文が同意トークンそのもの、パラメータは URL の ?type=...
            consent, src = strip_meta(b), q
        qtype = src.get("type")
        try:
            params = query_params(qtype, src.get("age"), src.get("claimed_name") or src.get("claimed-name"),
                                  src.get("carrier"))
            r = run_query(self.hub, self.party_key(u["party"]), u["party"], consent, qtype, params,
                          progress=lambda m: log.debug("%s: %s", u["username"], m))
        except ClientError as e:
            self.audit(b, u["username"], "query", False, qtype=qtype, error=str(e))
            raise ApiError(e.status, f"{e}" + (f" {json.dumps(e.detail, ensure_ascii=False)}" if e.detail else ""))
        except (HttpError, OSError, ValueError) as e:
            self.audit(b, u["username"], "query", False, qtype=qtype, error=str(e))
            raise ApiError(502, f"照会に失敗: {e}")
        rec = {"time": time.time(), "username": u["username"], "subject": consent["subject"],
               "qtype": qtype, "params": params, **r["result"]}
        os.makedirs(os.path.join(self.data_dir, "vendor-db"), exist_ok=True)
        with self._key_lock, open(os.path.join(self.data_dir, "vendor-db", f"{u['party']}.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        self.audit(b, u["username"], "query", True, qtype=qtype, selected=r["selected"],
                   elapsed=r["elapsed"], **({"over": r["result"]["over"]} if "over" in r["result"] else {}),
                   **({"match": r["result"]["match"]} if "match" in r["result"] else {}))
        return {**r["result"], "selected": r["selected"], "round": r["round"], "elapsed": r["elapsed"]}

    def redeem(self, b):
        u = self.auth(b, "carrier")
        token = str(b.get("token") or b.get("_query", {}).get("token") or "")
        servers = b.get("servers") or b.get("_query", {}).get("servers") or []
        if isinstance(servers, str):
            servers = [s for s in servers.split(",") if s]
        if not re.fullmatch(r"[0-9a-f]{30}", token) or not servers:
            raise ApiError(400, "token（30桁の16進）と servers が必要")
        try:
            addr = run_redeem(self.hub, self.party_key(u["party"]), u["party"], token, list(servers))
        except ClientError as e:
            self.audit(b, u["username"], "redeem", False, token=token[:6], error=str(e))
            raise ApiError(e.status, f"{e}" + (f" {json.dumps(e.detail, ensure_ascii=False)}" if e.detail else ""))
        except (HttpError, OSError, ValueError) as e:
            self.audit(b, u["username"], "redeem", False, token=token[:6], error=str(e))
            raise ApiError(502, f"引き換えに失敗: {e}")
        self.audit(b, u["username"], "redeem", True, token=token[:6], servers=servers)  # 住所は記録しない
        return {"address": addr}

    def records(self, b):
        u = self.auth(b, "vendor")
        path = os.path.join(self.data_dir, "vendor-db", f"{u['party']}.jsonl")
        limit = int(b.get("_query", {}).get("limit", "50"))
        if not os.path.exists(path):
            return {"records": []}
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()[-limit:]
        return {"records": [json.loads(x) for x in lines]}

    # ================================================================ 管理
    def admin_add_user(self, b):
        self.admin(b)
        username, password = str(b.get("username", "")), str(b.get("password", ""))
        role, party = b.get("role"), str(b.get("party", ""))
        if not USERNAME_RE.match(username):
            raise ApiError(400, "username は英数字と _ . - の1〜64文字")
        if len(password) < MIN_PASSWORD:
            raise ApiError(400, f"password は {MIN_PASSWORD} 文字以上")
        if role not in ROLES:
            raise ApiError(400, "role は vendor か carrier")
        if not PARTY_RE.match(party):
            raise ApiError(400, "party（ベンダ・配送事業者のID）が不正")
        if self.store.q("SELECT 1 FROM api_users WHERE username=?", (username,)):
            raise ApiError(409, f"{username} は登録済み")
        other = self.store.q("SELECT role FROM api_users WHERE party=? LIMIT 1", (party,))
        if other and other[0][0] != role:
            raise ApiError(409, f"{party} は {other[0][0]} として使われている")
        self.ensure_party(party, role, bool(b.get("force")))
        salt = secrets.token_bytes(16)
        self.store.x("INSERT INTO api_users(username, pw_salt, pw_hash, role, party, created) VALUES (?, ?, ?, ?, ?, ?)",
                     (username, salt.hex(), hash_password(password, salt), role, party, time.time()))
        self.audit(b, username, "admin:add_user", True, role=role, party=party)
        log.info("API 利用者を登録: %s（%s / %s）", username, role, party)
        return {"ok": True, "username": username, "role": role, "party": party}

    def ensure_party(self, party: str, role: str, force: bool):
        """所属（ベンダ・配送事業者）の鍵を用意し、hub に公開鍵を登録する。"""
        with self._key_lock:
            path = os.path.join(self.data_dir, "parties", f"{party}.key")
            key = Key.load_or_create(path)
            try:
                cur = http_json("GET", f"{self.hub}/parties/{party}")
            except HttpError as e:
                if e.status != 404:
                    raise ApiError(502, f"hub に問い合わせできない: {e}")
                cur = None
            if cur and cur.get("pubkey") == key.public_hex:
                if cur.get("role") != role:
                    raise ApiError(409, f"{party} は hub に {cur.get('role')} として登録済み")
                return
            if cur and not force:
                raise ApiError(409, f"{party} は hub に別の鍵で登録済み（dpqctl party add で作ったもの）。"
                                    "別の ID にするか、force で dpq-api の鍵に置き換える")
            http_json("POST", self.hub + "/parties", {"id": party, "role": role, "pubkey": key.public_hex},
                      headers={"X-DPQ-Admin-Token": self.admin_token})
            log.info("hub に %s（%s）の公開鍵を登録", party, role)

    def admin_list_users(self, b):
        self.admin(b)
        rows = self.store.q("SELECT username, role, party, disabled, created, last_login, locked_until "
                            "FROM api_users ORDER BY username")
        now = time.time()
        out = []
        for un, role, party, dis, created, last, locked in rows:
            n = self.store.q("SELECT COUNT(*) FROM api_tokens WHERE username=? AND revoked=0 AND expires>?",
                             (un, now))[0][0]
            out.append({"username": un, "role": role, "party": party, "disabled": bool(dis),
                        "created": created, "last_login": last, "locked": bool(locked and locked > now),
                        "active_tokens": n})
        return {"users": out}

    def _user_exists(self, username):
        if not self.store.q("SELECT 1 FROM api_users WHERE username=?", (username,)):
            raise ApiError(404, f"{username} は未登録")

    def admin_set_password(self, b, username):
        self.admin(b)
        self._user_exists(username)
        password = str(b.get("password", ""))
        if len(password) < MIN_PASSWORD:
            raise ApiError(400, f"password は {MIN_PASSWORD} 文字以上")
        salt = secrets.token_bytes(16)
        with self.store.tx():
            self.store.db.execute("UPDATE api_users SET pw_salt=?, pw_hash=?, failures=0, locked_until=NULL "
                                  "WHERE username=?", (salt.hex(), hash_password(password, salt), username))
            self.store.db.execute("UPDATE api_tokens SET revoked=1 WHERE username=?", (username,))
        self.audit(b, username, "admin:password", True)
        return {"ok": True, "tokens_revoked": True}

    def admin_set_disabled(self, b, username, disabled):
        self.admin(b)
        self._user_exists(username)
        with self.store.tx():
            self.store.db.execute("UPDATE api_users SET disabled=?, failures=0, locked_until=NULL WHERE username=?",
                                  (disabled, username))
            if disabled:
                self.store.db.execute("UPDATE api_tokens SET revoked=1 WHERE username=?", (username,))
        self.audit(b, username, "admin:disable" if disabled else "admin:enable", True)
        return {"ok": True, "disabled": bool(disabled)}

    def admin_delete_user(self, b, username):
        self.admin(b)
        self._user_exists(username)
        with self.store.tx():
            self.store.db.execute("DELETE FROM api_tokens WHERE username=?", (username,))
            self.store.db.execute("DELETE FROM api_users WHERE username=?", (username,))
        self.audit(b, username, "admin:delete", True)
        return {"ok": True}

    def admin_log(self, b):
        self.admin(b)
        limit = int(b.get("_query", {}).get("limit", "50"))
        rows = self.store.q("SELECT time, username, client, action, ok, info FROM api_log ORDER BY id DESC LIMIT ?",
                            (limit,))
        return {"log": [{"time": t, "username": u, "client": c, "action": a, "ok": bool(o),
                         "info": json.loads(i or "{}")} for t, u, c, a, o, i in reversed(rows)]}


def main(argv=None):
    ap = argparse.ArgumentParser(prog="dpq-api", description="DPQ HTTP API（ベンダの照会・配送事業者の引き換え）")
    ap.add_argument("--config", default="/etc/dpq/api.conf")
    a = ap.parse_args(argv)
    cfg = load_config(a.config, "api")
    setup_logging(cfg.get("log_level", "INFO"))
    api = Api(cfg)
    serve(api.router, cfg.get("listen", "0.0.0.0:8710"), "api").serve_forever()


if __name__ == "__main__":
    main()
