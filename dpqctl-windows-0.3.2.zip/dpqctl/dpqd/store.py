"""SQLite による永続化（hub とサーバで共用）。"""
from __future__ import annotations

import json
import os
import sqlite3
import threading

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
-- サーバ：利用者と断片
CREATE TABLE IF NOT EXISTS subjects (subject TEXT PRIMARY KEY, user_pubkey TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS shares (subject TEXT NOT NULL, field TEXT NOT NULL, value TEXT NOT NULL,
                                   PRIMARY KEY (subject, field));
CREATE TABLE IF NOT EXISTS used_nonces (subject TEXT NOT NULL, nonce TEXT NOT NULL,
                                        until_round INTEGER NOT NULL, PRIMARY KEY (subject, nonce));
CREATE TABLE IF NOT EXISTS tokens (token TEXT PRIMARY KEY, subject TEXT NOT NULL, carrier TEXT NOT NULL,
                                   until_round INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT, entry TEXT NOT NULL,
                                  hash TEXT NOT NULL);
-- 共通：名簿の版
CREATE TABLE IF NOT EXISTS directory (version INTEGER PRIMARY KEY, doc TEXT NOT NULL);
-- hub：掲示板と登録者
CREATE TABLE IF NOT EXISTS board (digest TEXT PRIMARY KEY, consent_id TEXT NOT NULL, poster TEXT NOT NULL,
                                  round INTEGER NOT NULL, posted_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS board_cid ON board (consent_id);
CREATE TABLE IF NOT EXISTS parties (id TEXT PRIMARY KEY, role TEXT NOT NULL, pubkey TEXT NOT NULL);
"""


class Store:
    def __init__(self, path: str):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript(SCHEMA)
        self.lock = threading.RLock()

    def q(self, sql: str, args=()):
        with self.lock:
            return self.db.execute(sql, args).fetchall()

    def x(self, sql: str, args=()):
        with self.lock:
            self.db.execute(sql, args)

    def tx(self):
        """複数の書き込みをまとめる： with store.tx(): ..."""
        store = self

        class _T:
            def __enter__(self_):
                store.lock.acquire()
                store.db.execute("BEGIN")

            def __exit__(self_, et, ev, tb):
                store.db.execute("ROLLBACK" if et else "COMMIT")
                store.lock.release()
        return _T()

    def get_meta(self, key: str, default=None):
        r = self.q("SELECT value FROM meta WHERE key=?", (key,))
        return json.loads(r[0][0]) if r else default

    def set_meta(self, key: str, value):
        self.x("INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)", (key, json.dumps(value)))

    def directory_versions(self) -> list:
        return [json.loads(d) for (d,) in self.q("SELECT doc FROM directory ORDER BY version")]

    def add_directory_version(self, v: dict):
        self.x("INSERT INTO directory(version, doc) VALUES (?, ?)", (v["version"], json.dumps(v)))
