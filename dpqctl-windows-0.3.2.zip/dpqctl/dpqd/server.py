"""dpq-server：断片保管サーバ。

・利用者の個人情報の「断片」だけを SQLite に保存する
・照会を自分で検証する（ベンダ署名、レート制限、本人同意、事前掲示、ビーコン、名簿、選定）
・選ばれたサーバ同士で HTTP 越しに秘密計算し、決められた回路の結果の断片だけを返す
・すべての出来事をハッシュチェーンの監査ログに残す
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import threading
import time
import unicodedata
from collections import deque
from datetime import date

from . import protocol as pr
from . import shamir
from .common import (VERSION, ApiError, HttpError, Key, Router, canon, http_json, load_config,
                     log, require_admin, serve, setup_logging, strip_meta, verify)
from .field import P
from .mpc import Party, less_than_public, masked_difference
from .store import Store


def name_to_field(name: str) -> int:
    n = "".join(unicodedata.normalize("NFKC", name).split())
    return int.from_bytes(hashlib.sha256(n.encode()).digest(), "big") % P


def years_before(d: date, years: int) -> date:
    try:
        return d.replace(year=d.year - years)
    except ValueError:
        return d.replace(year=d.year - years, day=28)


class Mailbox:
    """サーバ間メッセージの受け箱。"""

    def __init__(self):
        self.cond = threading.Condition()
        self.box = {}

    def put(self, key, value):
        with self.cond:
            self.box[key] = value
            self.cond.notify_all()

    def get(self, key, timeout=60.0):
        with self.cond:
            if not self.cond.wait_for(lambda: key in self.box, timeout):
                raise TimeoutError(f"受信タイムアウト {key}")
            return self.box.pop(key)

    def drop_session(self, sid):
        with self.cond:
            for k in [k for k in self.box if k[0] == sid]:
                del self.box[k]


class HttpNet:
    """1セッション分のサーバ間通信。送信には自分の運営事業者鍵で署名する。"""

    def __init__(self, server: "ShareServer", sid: str, members_by_x: dict):
        self.s, self.sid, self.members = server, sid, members_by_x

    def send(self, dst_x, tag, value):
        msg = {"sid": self.sid, "src": self.s.x, "tag": tag, "value": str(value)}
        msg["sig"] = self.s.key.sign(canon({k: msg[k] for k in ("sid", "src", "tag", "value")}))
        http_json("POST", self.members[dst_x]["url"] + "/mpc/msg", msg, timeout=30)

    def recv(self, src_x, tag):
        return int(self.s.mailbox.get((self.sid, src_x, tag)))


class ShareServer:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.id = cfg["id"]
        self.x = int(cfg["x"])
        self.region = cfg.get("region", "")
        self.operator = cfg.get("operator", self.id)
        self.url = cfg["public_url"].rstrip("/")
        self.hub = cfg["hub_url"].rstrip("/")
        self.admin_token = cfg.get("admin_token", "")
        self.rate_limit = int(cfg.get("rate_limit", "30"))
        self.data_dir = cfg.get("data_dir", f"/var/lib/dpq/server-{self.id}")
        os.makedirs(self.data_dir, exist_ok=True)
        self.store = Store(os.path.join(self.data_dir, "server.db"))
        self.key = Key.load_or_create(os.path.join(self.data_dir, "operator.key"))
        self.mailbox = Mailbox()
        self.sessions: dict = {}
        self.lock = threading.RLock()
        self._rate: dict = {}
        self._parties: dict = {}
        self.beacon = None
        self.versions = self.store.directory_versions()

        self.router = Router()
        r = self.router.add
        r("GET", "/health", lambda b: {"ok": True, "version": VERSION})
        r("GET", "/info", self.info)
        r("POST", "/directory/approve", self.approve_directory)
        r("POST", "/directory/sync", lambda b: {"synced": self.sync_directory()})
        r("POST", "/register", self.register)
        r("POST", "/session/open", self.open_session)
        r("POST", "/session/run", self.run_session)
        r("GET", r"/session/([0-9a-f]+)/output", self.session_output)
        r("POST", "/mpc/msg", self.mpc_msg)
        r("POST", "/redeem", self.redeem)
        r("POST", "/audit", self.audit_for)
        r("POST", "/refresh/run", self.refresh_run)
        r("POST", "/refresh/delta", self.refresh_delta)

    # ================================================================ 基盤
    def info(self, b=None):
        latest = self.versions[-1]["version"] if self.versions else None
        return {"id": self.id, "x": self.x, "region": self.region, "operator": self.operator,
                "url": self.url, "pubkey": self.key.public_hex, "epoch": self.store.get_meta("epoch", 0),
                "dir_version": latest, "subjects": self.store.q("SELECT COUNT(*) FROM subjects")[0][0],
                "version": VERSION}

    def ensure_beacon(self):
        if self.beacon is not None:
            return
        b = http_json("GET", self.hub + "/beacon")
        pinned = self.store.get_meta("anchor")
        if pinned is None:
            self.store.set_meta("anchor", b["anchor"])
            pinned = b["anchor"]
            log.info("ビーコンの起点を記録: %s…", pinned[:16])
        elif pinned != b["anchor"]:
            raise ApiError(503, "hub のビーコン起点が記録と違う（hub が作り直された可能性）")
        self.beacon = pr.BeaconVerifier(pinned)

    def current_round(self) -> int:
        return http_json("GET", self.hub + "/beacon")["round"]

    def party(self, pid):
        c = self._parties.get(pid)
        if c and time.time() - c[0] < 60:
            return c[1]
        try:
            p = http_json("GET", f"{self.hub}/parties/{pid}")
        except HttpError:
            return None
        self._parties[pid] = (time.time(), p)
        return p

    def log_event(self, subject=None, **entry):
        with self.store.lock:
            row = self.store.q("SELECT hash FROM audit ORDER BY id DESC LIMIT 1")
            entry.update(server=self.id, time=round(time.time(), 3), subject=subject,
                         prev=row[0][0] if row else "0" * 64)
            h = hashlib.sha256(canon(entry)).hexdigest()
            entry["hash"] = h
            self.store.x("INSERT INTO audit(subject, entry, hash) VALUES (?, ?, ?)",
                         (subject, json.dumps(entry, ensure_ascii=False), h))

    # ================================================================ 名簿
    def sync_directory(self) -> int:
        """hub から未取得の版を取り込む。署名は自分でも検証する。"""
        got = http_json("GET", self.hub + "/directory")["versions"]
        added = 0
        with self.lock:
            for v in got[len(self.versions):]:
                prev = self.versions[-1] if self.versions else None
                genesis = self.versions[0] if self.versions else v
                pr.verify_dir_version(v, prev, None if prev is None else genesis)
                self.store.add_directory_version(v)
                self.versions.append(v)
                added += 1
                log.info("名簿 第%d版 を取り込み（ラウンド%d から有効）", v["version"], v["effective_round"])
        return added

    def approve_directory(self, b):
        v = strip_meta(b)
        self.sync_directory()
        latest = self.versions[-1] if self.versions else None
        if latest is None:
            me = [m for m in v["members"] if m["id"] == self.id]
            if not me or me[0]["pubkey"] != self.key.public_hex or me[0]["x"] != self.x:
                raise ApiError(400, "初版に自分の情報が正しく含まれていない")
        elif v["version"] != latest["version"] + 1 or v["policy"] != latest["policy"]:
            raise ApiError(400, "版番号またはポリシーが不正")
        return {"operator": self.operator, "sig": self.key.sign(pr.dir_body(v))}

    # ================================================================ 登録
    def register(self, b):
        b = strip_meta(b)
        subject, pub, shares = b["subject"], b["user_pubkey"], b["shares"]
        if not verify(pub, canon({"subject": subject, "user_pubkey": pub, "shares": shares}), b["sig"]):
            raise ApiError(403, "利用者の署名が不正")
        row = self.store.q("SELECT user_pubkey FROM subjects WHERE subject=?", (subject,))
        if row and row[0][0] != pub:
            raise ApiError(403, "この利用者IDは別の鍵で登録済み")
        with self.store.tx():
            self.store.db.execute("INSERT OR REPLACE INTO subjects(subject, user_pubkey) VALUES (?, ?)",
                                  (subject, pub))
            self.store.db.execute("DELETE FROM shares WHERE subject=?", (subject,))
            self.store.db.executemany("INSERT INTO shares(subject, field, value) VALUES (?, ?, ?)",
                                      [(subject, f, str(v)) for f, v in shares.items()])
        self.log_event(subject, event="registered", fields=len(shares))
        return {"ok": True}

    def shares_of(self, subject) -> dict:
        return {f: int(v) for f, v in self.store.q("SELECT field, value FROM shares WHERE subject=?",
                                                     (subject,))}

    # ================================================================ 照会の検証
    def reject(self, req, reason):
        self.log_event(req.get("subject"), event="rejected", vendor=req.get("vendor"),
                       qtype=req.get("qtype"), reason=reason)
        raise ApiError(403, f"[{self.id}] {reason}")

    def open_session(self, b):
        req = strip_meta(b)
        self.ensure_beacon()
        with self.lock:
            digest = pr.request_digest(req)
            now = time.time()
            # 1. ベンダ認証
            v = self.party(req["vendor"])
            if not v or v["role"] != "vendor" or not verify(v["pubkey"], digest.encode(), req.get("vendor_sig", "")):
                self.reject(req, "ベンダ署名が不正")
            # 2. レート制限（失敗した試行も数える）
            q = self._rate.setdefault(req["vendor"], deque())
            while q and now - q[0] > 60:
                q.popleft()
            q.append(now)
            if len(q) > self.rate_limit:
                self.reject(req, "レート制限超過")
            # 3. ポリシー
            if req["qtype"] not in pr.PURPOSE:
                self.reject(req, "未定義の照会種別")
            if req["qtype"] == "age_over" and req["params"].get("age") not in pr.ALLOWED_AGES:
                self.reject(req, "許可されていない年齢閾値")
            row = self.store.q("SELECT user_pubkey FROM subjects WHERE subject=?", (req["subject"],))
            if not row:
                self.reject(req, "対象者が未登録")
            # 4. 本人同意
            c, rnd = req["consent"], int(req["round"])
            if not verify(row[0][0], pr.consent_body(c), c.get("sig", "")):
                self.reject(req, "同意トークンの署名が不正")
            if c["subject"] != req["subject"] or c["vendor"] != req["vendor"]:
                self.reject(req, "同意の対象者／ベンダが不一致")
            if c["purpose"] != pr.PURPOSE[req["qtype"]]:
                self.reject(req, "同意の目的外の照会")
            if any(req["params"].get(k) != val for k, val in c["scope"].items()):
                self.reject(req, "同意の範囲外のパラメータ")
            if c["iat"] > now + pr.MAX_CLOCK_SKEW:
                self.reject(req, "同意の発行時刻が未来（端末の時計のずれ）")
            if c["exp"] < now or c["exp"] - c["iat"] > pr.MAX_CONSENT_TTL:
                self.reject(req, "同意の有効期限切れ、または有効期間が長すぎる")
            if c["until"] - c["from"] > pr.MAX_CONSENT_ROUNDS:
                self.reject(req, "同意の有効回数が長すぎる")
            if not (c["from"] <= rnd <= c["until"]):
                self.reject(req, "同意の有効回を外れている（期限切れ）")
            self.store.x("DELETE FROM used_nonces WHERE until_round < ?", (rnd,))
            if self.store.q("SELECT 1 FROM used_nonces WHERE subject=? AND nonce=?", (c["subject"], c["nonce"])):
                self.reject(req, "同意トークンの再利用")
            # 5. 事前掲示とビーコン
            try:
                e = http_json("GET", f"{self.hub}/board/entry/{digest}")
            except HttpError:
                e = None
            if e is None or e["round"] >= rnd:
                self.reject(req, "照会がビーコン公開前に掲示されていない")
            cid = pr.consent_id(c)
            if e["poster"] != req["vendor"] or e["consent_id"] != cid:
                self.reject(req, "掲示者または同意IDが依頼書と不一致")
            if e["round"] < c["from"]:
                self.reject(req, "同意の発行より前の掲示")
            cnt = http_json("GET", f"{self.hub}/board/count?consent_id={cid}&vendor={req['vendor']}")["count"]
            if cnt != 1:
                self.reject(req, "同じ同意で複数の照会を掲示（選定の操作試行）")
            if not self.beacon.verify(rnd, req["beacon_value"]):
                self.reject(req, "ビーコン値が不正")
            # 6. 名簿と選定
            if not self.versions or req["dir_version"] > self.versions[-1]["version"]:
                try:
                    self.sync_directory()
                except Exception:  # noqa: BLE001
                    pass
            if not self.versions:
                self.reject(req, "名簿が未初期化")
            truth = pr.version_for_round(self.versions, rnd)
            if (req["dir_version"], req["dir_hash"]) != (truth["version"], pr.dir_hash(truth)):
                self.reject(req, f"依頼書の名簿（第{req['dir_version']}版）が正解（第{truth['version']}版）と不一致")
            pol = truth["policy"]
            expected = pr.select_servers(truth["members"], req["beacon_value"], digest, int(pol["k"]),
                                         pol.get("distinct", "region"))
            if req["selected"] != expected:
                self.reject(req, "サーバ選定が公開乱数の結果と不一致")
            if self.id not in expected:
                self.reject(req, "このサーバは選定されていない")
            removing = pr.pending_removals(self.versions, rnd) & set(expected)
            if removing:
                self.reject(req, f"隔離予定のサーバ {sorted(removing)} が選定に含まれる（切り替え待ち）")

            self.store.x("INSERT INTO used_nonces(subject, nonce, until_round) VALUES (?, ?, ?)",
                         (c["subject"], c["nonce"], c["until"]))
            sid = digest[:32]
            members = {m["x"]: m for m in truth["members"] if m["id"] in expected}
            self.sessions[sid] = {"req": req, "members": members, "t": int(pol["t"]),
                                  "output": None, "error": None, "created": now}
            self.log_event(req["subject"], event="accepted", vendor=req["vendor"], qtype=req["qtype"],
                           purpose=c["purpose"], session=sid, selected=expected)
            # 古いセッションの掃除
            for k in [k for k, s in self.sessions.items() if now - s["created"] > 600]:
                del self.sessions[k]
                self.mailbox.drop_session(k)
            return {"sid": sid}

    # ================================================================ 秘密計算
    def run_session(self, b):
        sid = b["sid"]
        s = self.sessions.get(sid)
        if not s:
            raise ApiError(404, "セッションがない")
        threading.Thread(target=self._compute, args=(sid,), daemon=True).start()
        return {"started": True}

    def _compute(self, sid):
        s = self.sessions[sid]
        req = s["req"]
        try:
            party = Party(self.x, sorted(s["members"]), s["t"], HttpNet(self, sid, s["members"]))
            data = self.shares_of(req["subject"])
            if req["qtype"] == "age_over":
                limit = years_before(date.today(), int(req["params"]["age"]))
                bits = [data[f"birth_b{i}"] for i in range(pr.BIRTH_BITS)]
                out = less_than_public(party, bits, limit.toordinal() + 1)
            elif req["qtype"] == "name_match":
                out = masked_difference(party, data["name_h"], name_to_field(req["params"]["claimed_name"]))
            else:  # delivery_token
                token = hashlib.sha256(b"delivery-token" + bytes.fromhex(pr.request_digest(req))).hexdigest()[:30]
                self.store.x("INSERT OR REPLACE INTO tokens(token, subject, carrier, until_round, used) "
                             "VALUES (?, ?, ?, ?, 0)",
                             (token, req["subject"], req["params"]["carrier"], int(req["round"]) + 100000))
                out = int(token, 16)
            s["output"] = str(out % P)
            self.log_event(req["subject"], event="released", vendor=req["vendor"], qtype=req["qtype"], session=sid)
        except Exception as e:  # noqa: BLE001
            log.exception("計算に失敗 sid=%s", sid)
            s["error"] = str(e)
        finally:
            self.mailbox.drop_session(sid)

    def session_output(self, b, sid):
        s = self.sessions.get(sid)
        if not s:
            raise ApiError(404, "セッションがない")
        return {"ready": s["output"] is not None or s["error"] is not None,
                "value": s["output"], "error": s["error"]}

    def mpc_msg(self, b):
        sid, src = b["sid"], int(b["src"])
        s = self.sessions.get(sid)
        if not s or src not in s["members"]:
            raise ApiError(403, "このセッションの参加者ではない")
        body = canon({k: b[k] for k in ("sid", "src", "tag", "value")})
        if not verify(s["members"][src]["pubkey"], body, b["sig"]):
            raise ApiError(403, "送信元の署名が不正")
        self.mailbox.put((sid, src, b["tag"]), b["value"])
        return {"ok": True}

    # ================================================================ 配送トークン
    def redeem(self, b):
        b = strip_meta(b)
        c = self.party(b["carrier"])
        msg = canon({"carrier": b["carrier"], "token": b["token"], "t": b["t"]})
        if not c or c["role"] != "carrier" or not verify(c["pubkey"], msg, b["sig"]) \
                or abs(time.time() - b["t"]) > 300:
            raise ApiError(403, f"[{self.id}] 配送事業者として認証できない")
        with self.store.tx():
            row = self.store.db.execute("SELECT subject, carrier, used FROM tokens WHERE token=?",
                                        (b["token"],)).fetchall()
            if not row or row[0][1] != b["carrier"]:
                raise ApiError(403, f"[{self.id}] トークンが存在しないか、宛先事業者が違う")
            if row[0][2]:
                raise ApiError(403, f"[{self.id}] トークンは使用済み")
            self.store.db.execute("UPDATE tokens SET used=1 WHERE token=?", (b["token"],))
        subject = row[0][0]
        self.log_event(subject, event="redeemed", vendor=b["carrier"], qtype="delivery_token")
        return {"shares": {f: str(v) for f, v in self.shares_of(subject).items() if f.startswith("addr_")}}

    # ================================================================ 監査ログ
    def audit_for(self, b):
        b = strip_meta(b)
        row = self.store.q("SELECT user_pubkey FROM subjects WHERE subject=?", (b["subject"],))
        if not row or not verify(row[0][0], canon({"audit": b["subject"], "t": b["t"]}), b["sig"]) \
                or abs(time.time() - b["t"]) > 300:
            raise ApiError(403, "監査ログ閲覧の署名が不正")
        return {"entries": [json.loads(e) for (e,) in
                            self.store.q("SELECT entry FROM audit WHERE subject=? ORDER BY id", (b["subject"],))]}

    # ================================================================ 断片の定期更新
    def refresh_run(self, b):
        require_admin(b, self.admin_token)
        epoch = int(b["epoch"])
        if epoch != self.store.get_meta("epoch", 0) + 1:
            raise ApiError(400, f"epoch は {self.store.get_meta('epoch', 0) + 1} を指定する")
        self.sync_directory()
        members = {m["x"]: m for m in self.versions[0]["members"]}  # 断片は初版の全メンバーが持つ
        t = int(self.versions[0]["policy"]["t"])
        xs = sorted(members)
        rows = self.store.q("SELECT subject, field FROM shares ORDER BY subject, field")
        deltas = {x: {} for x in xs}
        for subj, f in rows:
            z = shamir.split(0, t, xs)
            for x in xs:
                deltas[x].setdefault(subj, {})[f] = str(z[x])
        for x in xs:
            if x == self.x:
                continue
            msg = {"epoch": epoch, "src": self.x, "payload": deltas[x]}
            msg["sig"] = self.key.sign(canon(msg))
            http_json("POST", members[x]["url"] + "/refresh/delta", msg, timeout=60)
        received = {self.x: deltas[self.x]}
        for x in xs:
            if x != self.x:
                received[x] = self.mailbox.get(("refresh", epoch, x), timeout=120)
        with self.store.tx():
            for d in received.values():
                for subj, fields in d.items():
                    for f, val in fields.items():
                        cur =self.store.db.execute("SELECT value FROM shares WHERE subject=? AND field=?",
                                                    (subj, f)).fetchall()
                        if cur:
                            self.store.db.execute("UPDATE shares SET value=? WHERE subject=? AND field=?",
                                                  (str((int(cur[0][0]) + int(val)) % P), subj, f))
            self.store.db.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('epoch', ?)", (json.dumps(epoch),))
        log.info("断片を更新（epoch %d）", epoch)
        return {"ok": True, "epoch": epoch}

    def refresh_delta(self, b):
        b = strip_meta(b)
        src = int(b["src"])
        members = {m["x"]: m for m in self.versions[0]["members"]}
        if src not in members or not verify(members[src]["pubkey"],
                                            canon({k: b[k] for k in ("epoch", "src", "payload")}), b["sig"]):
            raise ApiError(403, "送信元の署名が不正")
        self.mailbox.put(("refresh", int(b["epoch"]), src), b["payload"])
        return {"ok": True}

    # ================================================================ 起動
    def background(self, interval: float):
        while True:
            try:
                self.ensure_beacon()
                self.sync_directory()
            except Exception as e:  # noqa: BLE001
                log.warning("hub との同期に失敗: %s", e)
            time.sleep(interval)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="dpq-server", description="DPQ 断片保管サーバ")
    ap.add_argument("--config", required=True)
    a = ap.parse_args(argv)
    cfg = load_config(a.config, "server")
    setup_logging(cfg.get("log_level", "INFO"))
    s = ShareServer(cfg)
    log.info("サーバ %s（x=%d, %s, %s）運営鍵 %s…", s.id, s.x, s.region, s.operator, s.key.public_hex[:16])
    threading.Thread(target=s.background, args=(float(cfg.get("sync_interval", "15")),), daemon=True).start()
    serve(s.router, cfg.get("listen", "0.0.0.0:8701"), f"server-{s.id}").serve_forever()


if __name__ == "__main__":
    main()
