@echo off
rem dpqctl for Windows: runs the dpqd package located next to this file
setlocal
set "PYTHONPATH=%~dp0;%PYTHONPATH%"
set "PYTHONUTF8=1"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m dpqd.cli %*
) else (
  python -m dpqd.cli %*
)
exit /b %errorlevel%
